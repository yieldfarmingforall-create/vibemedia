import { useRef, useCallback } from 'react';

// Returns event handlers that apply a CSS 3D tilt + glow effect on hover.
// Usage: <div {...tilt()} style={tiltStyle} />
export default function use3DTilt({ maxDeg = 14, glowColor = 'rgba(255,193,7,0.25)', scale = 1.03 } = {}) {
  const ref = useRef(null);

  const onMouseMove = useCallback((e) => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width  - 0.5;
    const y = (e.clientY - rect.top)  / rect.height - 0.5;
    const rotX = -y * maxDeg;
    const rotY =  x * maxDeg;
    el.style.transform = `perspective(900px) rotateX(${rotX}deg) rotateY(${rotY}deg) scale(${scale})`;
    el.style.boxShadow = `${rotY * -1.5}px ${rotX * 1.5}px 40px ${glowColor}`;
  }, [maxDeg, glowColor, scale]);

  const onMouseLeave = useCallback(() => {
    const el = ref.current;
    if (!el) return;
    el.style.transform = 'perspective(900px) rotateX(0deg) rotateY(0deg) scale(1)';
    el.style.boxShadow = 'none';
  }, []);

  const tiltStyle = {
    transformStyle: 'preserve-3d',
    transition: 'transform 0.15s ease, box-shadow 0.15s ease',
    willChange: 'transform',
  };

  return { ref, onMouseMove, onMouseLeave, tiltStyle };
}